# -*- coding: utf-8 -*-
"""
Created on Sat Jan  1 18:05:08 2022

@author: Utilizador
"""


    
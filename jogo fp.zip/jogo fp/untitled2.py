# -*- coding: utf-8 -*-
"""
Created on Wed Dec 29 15:47:04 2021

@author: Utilizador
"""

player={
        "nome":"Ze",
        "nivel":3,
        "vida":1000,
        "img":"razor.jpg",
        "ataque":500,
        "velocidade":50,
        "elemento1":"vento",
        "elemento2":"fogo"
        }

inimigo={
        "nome":"L",
        "nivel":2,
        "vida":1000,
        "img":"razor.jpg",
        "ataque":500,
        "velocidade":50,
        "elemento1":"fogo",
        
    }
op=1

def fcritico(player,inimigo,op):
    critico=1
    if op==1:
        if inimigo["elemento1"]=="eletro":
            critico=2
        elif inimigo["elemento1"]=="pedra":
            critico=0.5
        elif inimigo["elemento1"]=="vento":
            critico=0
    elif op==4:
        critico=0
        
    elif op==2:
        if player["elemento2"]=="fogo":
            if inimigo["elemento1"]=="metal":
                critico=2
            elif inimigo["elemento1"]=="natureza":
                critico=2
            elif inimigo["elemento1"]=="gelo":
                critico=2
            elif inimigo["elemento1"]=="agua":
                critico=0.5
            elif inimigo["elemento1"]=="pedra":
                critico=0.5
            elif inimigo["elemento1"]=="fogo":
                critico=0
            
        elif player["elemento2"]=="natureza":
            if inimigo["elemento1"]=="pedra":
                critico=2
            elif inimigo["elemento1"]=="agua":
                critico=2
            elif inimigo["elemento1"]=="fogo":
                critico=0.5
            elif inimigo["elemento1"]=="gelo":
                critico=0.5
            elif inimigo["elemento1"]=="natureza":
                critico=0
            
        elif player["elemento2"]=="pedra":
            if inimigo["elemento1"]=="gelo":
                critico=2
            elif inimigo["elemento1"]=="eletro":
                critico=2
            elif inimigo["elemento1"]=="metal":
                critico=0.5
            elif inimigo["elemento1"]=="agua":
                critico=0.5
            elif inimigo["elemento1"]=="pedra":
                critico=0
            
        elif player["elemento2"]=="metal":
            if inimigo["elemento1"]=="pedra":
                critico=2
            elif inimigo["elemento1"]=="gelo":
                critico=2
            elif inimigo["elemento1"]=="fogo":
                critico=0.5
            elif inimigo["elemento1"]=="eletro":
                critico=0.5
            elif inimigo["elemento1"]=="metal":
                critico=0
            
        elif player["elemento2"]=="gelo":
            if inimigo["elemento1"]=="natureza":
                critico=2
            elif inimigo["elemento1"]=="agua":
                critico=2
            elif inimigo["elemento1"]=="fogo":
                critico=0.5
            elif inimigo["elemento1"]=="pedra":
                critico=0.5
            elif inimigo["elemento1"]=="metal":
                critico=0.5
            elif inimigo["elemento1"]=="gelo":
                critico=0
            
        elif player["elemento2"]=="agua":
            if inimigo["elemento1"]=="fogo":
                critico=2
            elif inimigo["elemento1"]=="pedra":
                critico=2
            elif inimigo["elemento1"]=="natureza":
                critico=0.5
            elif inimigo["elemento1"]=="gelo":
                critico=0.5
            elif inimigo["elemento1"]=="eletro":
                critico=0.5
            elif inimigo["elemento1"]=="agua":
                critico=0
            
        elif player["elemento2"]=="eletro":
            if inimigo["elemento1"]=="metal":
                critico=2
            elif inimigo["elemento1"]=="agua":
                critico=2
            elif inimigo["elemento1"]=="pedra":
                critico=0.5
            elif inimigo["elemento1"]=="vento":
                critico=0.5
            elif inimigo["elemento1"]=="eletro":
                critico=0
    
    return critico


            
        
        

def combate(player,inimigo,op):
    while player["vida"]>0 and inimigo["vida"]>0:
        if op==1:
            texto=f"{player['nome']} usou {player['elemento1']}"
        elif op==2:
            texto=f"{player['nome']} usou {player['elemento2']}"
        elif op==3:
            texto=f"{player['nome']} usou Espadas"
        elif op==4:
            texto=f"{player['nome']} usou Escudo"
            
        print(texto)
         
        critico=fcritico(player, inimigo,op)
       
        
        if player["velocidade"]>=inimigo["velocidade"]:
            inimigo["vida"]=inimigo["vida"]-int(player["ataque"]*critico)
            
            if inimigo["vida"]>0:
                player["vida"]=player["vida"]-int(inimigo["ataque"]*critico)
                
            else:
                inimigo["vida"]=0
                
                print(f"{inimigo['nome']} morreu")
        else:
            player["vida"]=player["vida"]-int(inimigo["ataque"]*critico)
            
            if player["vida"]>0:
                 inimigo["vida"]=inimigo["vida"]-int(player["ataque"]*critico)
                 print(inimigo["vida"])
            else:
                print(f"{player['nome']} morreu")
                player["vida"]=0
        
                
        print(inimigo["vida"])
        print(player["vida"])
    
    
            
    
    
        
        
        
        
    return texto,player,inimigo


texto,player,inimigo=combate(player,inimigo, op)  
 
        